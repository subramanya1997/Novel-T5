python src/load_data.py \
    --data_dir="data" \
    --train_prefix="train" \
    --valid_prefix="valid" \
    --train_frac=0.85 \
    --model_type="gpt2"

